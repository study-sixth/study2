

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;
import javax.swing.table.*;
import java.util.Vector;

public class BorrowBookList
    extends JFrame
    implements ActionListener {
  /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
  DataBaseManager db = new DataBaseManager();
  ResultSet rs;
  Container c;
  JPanel panel1, panel2;
  JLabel bookNameLabel, studentNameLabel;
  JTextField bookNameTextField, studentNameTextField;
  JButton searchBtn, exitBtn;
  JTable table = null;
  DefaultTableModel defaultModel = null;
  public BorrowBookList() {
    super("������Ϣ��ѯ��");
    c = getContentPane();
    c.setLayout(new BorderLayout());
    bookNameLabel = new JLabel("����   ", JLabel.CENTER);
    studentNameLabel = new JLabel("������", JLabel.CENTER);
    bookNameTextField = new JTextField(15);
    studentNameTextField = new JTextField(15);
    searchBtn = new JButton("��ѯ");
    exitBtn = new JButton("�˳�");
    searchBtn.addActionListener(this);
    exitBtn.addActionListener(this);
    Box box1 = Box.createHorizontalBox();
    box1.add(studentNameLabel);
    box1.add(studentNameTextField);
    box1.add(searchBtn);
    Box box2 = Box.createHorizontalBox();
    box2.add(bookNameLabel);
    box2.add(bookNameTextField);
    box2.add(exitBtn);
    Box boxH = Box.createVerticalBox();
    boxH.add(box1);
    boxH.add(box2);
    boxH.add(Box.createVerticalGlue());
    panel1 = new JPanel();
    panel1.add(boxH);
    panel2 = new JPanel();
    String[] name = {
        "������ID", "������","�鼮ID", "����", "��������", "��������", "��������"};
    String[][] data = new String[0][0];
    defaultModel = new DefaultTableModel(data, name);
    table = new JTable(defaultModel);
    table.setPreferredScrollableViewportSize(new Dimension(600, 120));
    JScrollPane s = new JScrollPane(table);
    panel2.add(s);
    c.add(panel1, BorderLayout.NORTH);
    c.add(panel2, BorderLayout.SOUTH);
  }

  public void actionPerformed(ActionEvent e) {
    if (e.getSource() == exitBtn) {
      db.closeConnection();
      this.dispose();
    }
    else if (e.getSource() == searchBtn) {
//      String strSQL =
//          "select readername,bookname,borrowdate,returndate,borrowednumber from bookbrowse";
      String strSQL =
      "select readerid,readername,BookID,BookName,BorrowDate,ReturnDate,Borrowednumber from bookbrowse";
      String strSql = null;
      if (studentNameTextField.getText().trim().equals("") &&
          bookNameTextField.getText().trim().equals("")) {
        strSql = strSQL;
      }
      else if (studentNameTextField.getText().trim().equals("")) {
        strSql = strSQL + " where BookName='" +
            bookNameTextField.getText().trim() + "'";
      }
      else if (bookNameTextField.getText().trim().equals("")) {
        strSql = strSQL + " where readername='" +
            studentNameTextField.getText().trim() + "'";
      }
      else {
        strSql = strSQL + " where readername='" +
            studentNameTextField.getText().trim() + "'and bookName='" +
            bookNameTextField.getText().trim() + "'";
      }
      try {
        //����Ҫɾ��table�е����ݣ�
        int rowCount = defaultModel.getRowCount() - 1; //ȡ��table�е������У�
        int j = rowCount;
        for (int i = 0; i <= rowCount; i++) {
          defaultModel.removeRow(j); //ɾ��rowCount�е����ݣ�
          defaultModel.setRowCount(j); //��������������
          j = j - 1;
        }
        rs = db.getResult(strSql);
        while (rs.next()) {
          Vector data = new Vector();
          data.addElement(rs.getString(1));
          data.addElement(rs.getString(2));
          data.addElement(rs.getString(3));
          data.addElement(rs.getString(4));
          data.addElement(rs.getString(5));
          data.addElement(rs.getString(6));
          data.addElement(rs.getString(7));
          defaultModel.addRow(data);
        }
        table.revalidate();
      }
      catch (SQLException sqle) {
        System.out.println(sqle.toString());
      }
      catch (Exception ex) {
        System.out.println(ex.toString());
      }
    }
  }
}
